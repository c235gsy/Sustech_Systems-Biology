function dy=simpleode(t,y)
dy=y;