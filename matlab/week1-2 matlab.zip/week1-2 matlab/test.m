x=0:0.1:2*pi;
y=sin(x);
plot(x,y);
hold on
plot(x,cos(x),'r');
hold off